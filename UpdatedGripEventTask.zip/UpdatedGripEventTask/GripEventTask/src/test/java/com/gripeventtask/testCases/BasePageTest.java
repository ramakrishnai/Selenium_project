package com.gripeventtask.testCases;

import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.gripeventtask.pageObjects.BasePage;
import com.gripeventtask.utilities.ReadConfig;

public class BasePageTest{

	
	ReadConfig readconfig=new ReadConfig();
	public static Logger logger; //Added logger
	public String baseURL=readconfig.getApplicationURL();
	public String username=readconfig.getUserName();
	public String password=readconfig.getPassword();
	WebDriver driver;
		
//	public BasePageTest(WebDriver driver) {
//		this.driver= driver;
//	}

	@Parameters("browser")
	@BeforeClass
	public WebDriver setup(String br)
	{
		logger = Logger.getLogger("Expedia"); //Added logger
		PropertyConfigurator.configure("Log4j.properties");//Added logger
		
		if (br.equals("firefox")) {
			// FireFox Browser
			System.setProperty("webdriver.gecko.driver",readconfig.getFirefoxPath());
			driver = new FirefoxDriver();
			
		}

		else if (br.equals("chrome")) {
			// opens the browser
			System.setProperty("webdriver.chrome.driver", readconfig.getChromePath());
			driver = new ChromeDriver();
			
		}
		
		else if (br.equals("ie")) {
			// opens the browser
			System.setProperty("webdriver.ie.driver", readconfig.getIEPath());
			driver = new InternetExplorerDriver();
		}

		// Global implicit Wait
		driver.navigate().to(baseURL);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("in Base page test");
		return driver;
	}
	
	@AfterClass
	public void tearDown()
	{
		driver.quit();
	}
	
}