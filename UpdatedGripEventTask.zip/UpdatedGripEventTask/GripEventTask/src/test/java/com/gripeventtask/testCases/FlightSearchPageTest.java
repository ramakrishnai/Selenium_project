package com.gripeventtask.testCases;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.gripeventtask.pageObjects.FlightSearchPage;



public class FlightSearchPageTest extends BasePageTest{
	
	
		/* Verify that it does not let you proceed if there are insufficient information. Example: This test does not enter a departing date*/
		@Test(priority=0)
		public void cannotProceedSearchWithInsufficientInformation() {
			FlightSearchPage flightSearch = new FlightSearchPage(driver);
			flightSearch.clickFlightsTab()
					.clickRoundTripTab()
					.searchForDepartingAirport("London")
					.searchForArrivingAirport("Amsterdam")
					.clickSearchButton()
					.closePopup();
			Assert.assertTrue(flightSearch.errorMessageDisplayed());
			logger.info("Error Message for insufficient data");
		}
		
		/* Verify the search flow of a round-trip */
		@Test(priority=1)
		public void searchForFlight() {
			FlightSearchPage flightSearch = new FlightSearchPage(driver);
			try {
				flightSearch.clickFlightsTab()
					.clickRoundTripTab();
			} catch(Exception e) {
				
			}
			//Search for an airport in the 'Flying from' text box and select the matching text
			flightSearch.searchForDepartingAirport("London")
				.clickFromAirportSuggestionsList("London (LHR - London (LHR-Heathrow))")

			//Search for an airport in the 'Going to' text box and select the matching text
				.searchForArrivingAirport("Amsterdam")
				.clickFromAirportSuggestionsList("Amsterdam (AMS - Schipol)")
			
			//Select the date in the calendar box
				.openCalendarSelection()
				.chooseDate("30");
		}

		/* Verify the 'Advanced options' drop-down can be opened, and the preferred class can be changed */
		@Test(priority=2)
		public void editFlight() {
			FlightSearchPage flightSearch = new FlightSearchPage(driver);
			flightSearch.clickAdvancedOptions();
			//Soft Assertion
			SoftAssert verifyClass = new SoftAssert();
			flightSearch.selectDifferentClass("first");
			verifyClass.assertEquals(flightSearch.selectedOption(), "First class");
			flightSearch.selectDifferentClass("business");
			verifyClass.assertEquals(flightSearch.selectedOption(), "Business");
			flightSearch.selectDifferentClass("premium");
			verifyClass.assertEquals(flightSearch.selectedOption(), "Premium economy");
			verifyClass.assertAll();
		}
		
		/* Verify that clicking on 'Search' loads a new page and flights are loaded */
		@Test(priority=3)
		public void verifySearchButtonLoadsNewPage() {
			FlightSearchPage flightSearch = new FlightSearchPage(driver);
			flightSearch.clickSearchButton();
			Assert.assertTrue(flightSearch.finishedLoading());
		}
	

}
