#Description of the project

This project is designed for Expedia Test Automation Assignment by using the below tools:
- Java Language
- Selenium-TestNg Framework
- Eclipse IDE

#Scenarios

- Base Page: Includes all the prerequisite functions for the application
- Home Page: Includes the functionality flow of the Expedia Home Page
- Singin Page: Includes the functionality flow of the Expedia Signin Page
- Flisht Search Page: Includes the functionality flow of the Expedia Round Trip - Flight Search Page

#Browsers

- Chrome
- Firefox
- Internet Explorer








 